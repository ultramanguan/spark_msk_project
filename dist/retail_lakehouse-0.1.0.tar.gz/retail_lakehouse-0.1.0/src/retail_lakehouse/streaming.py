from __future__ import annotations

from typing import Callable

from delta.tables import DeltaTable
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F


def deduplicate_stream(df: DataFrame, watermark_col: str = "event_ts", watermark_delay: str = "10 minutes",
                        dedup_keys: list[str] | None = None) -> DataFrame:
    """Watermark + de-duplicate a streaming DataFrame. Required before any stateful aggregation
    that should run in `append` output mode."""
    keys = dedup_keys or ["event_id"]
    return df.withWatermark(watermark_col, watermark_delay).dropDuplicates(keys)


def windowed_revenue(df: DataFrame, window_duration: str = "5 minutes",
                      watermark_delay: str = "10 minutes") -> DataFrame:
    """Aggregate purchase events into event-time windows. Requires `df` to already carry a watermark
    (e.g. via `deduplicate_stream`) so `append` output mode is valid."""
    return (
        df.filter(F.col("event_type").isin("purchase", "checkout"))
          .groupBy(F.window(F.col("event_ts"), window_duration), "category")
          .agg(
              F.countDistinct("event_id").alias("orders"),
              F.round(F.sum("gross_amount"), 2).alias("revenue"),
          )
    )


def make_gold_upsert(target_table: str, merge_keys: list[str], update_cols: list[str]) -> Callable:
    """Build a `foreachBatch` function that MERGEs a micro-batch's aggregated rows into a gold
    Delta table by `merge_keys`, updating `update_cols` on match and inserting otherwise.

    This is the idempotent-upsert pattern used to make a streaming aggregation safe to replay:
    re-running the same micro-batch after a failure updates the same rows instead of duplicating them.
    """
    merge_condition = " AND ".join(f"t.{k} = s.{k}" for k in merge_keys)
    update_set = {c: f"s.{c}" for c in update_cols}

    def upsert(batch_df: DataFrame, batch_id: int) -> None:
        spark: SparkSession = batch_df.sparkSession
        target = DeltaTable.forName(spark, target_table)
        (
            target.alias("t")
            .merge(batch_df.alias("s"), merge_condition)
            .whenMatchedUpdate(set=update_set)
            .whenNotMatchedInsertAll()
            .execute()
        )

    return upsert
